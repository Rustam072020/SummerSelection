//
//  CheckingView.swift
//  LoginApp
//


import UIKit

class CheckingView: UIView {

    @IBOutlet var label: UILabel!
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
